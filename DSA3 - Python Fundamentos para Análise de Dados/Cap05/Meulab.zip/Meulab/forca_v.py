# -*- coding: utf-8 -*-

# Jogo da Forca

# Import
import random

# board (tabuleiro)
board = ['''
============= JOGO DA FORCA GALO DOIDO =============
             bora enforcar as rapozetes

  +---+
  |   |
      |
      |
      |
      |
      |
  ========= ''','''

  +---+
  |   |
  0   |
      |
      |
      |
      |
  ========= ''','''
  
  +---+
  |   |
  0   |
  |   |
      |
      |
      |
  ========= ''','''
  
  +---+
  |   |
  0   |
 /|   |
      |
      |
      |
  ========= ''','''
  
  +---+
  |   |
  0   |
 /|\  |
      |
      |
      |
  ========= ''','''   
  
  +---+
  |   |
  0   |
 /|\  |
  |   |
      |
      |
  ========= ''',''' 
  
  +---+
  |   |
  0   |
 /|\  |
  |   |
 /    |
      |
  ========= ''',''' 

  
  +---+
  |   |
  0   |
 /|\  |
  |   |
 / \  |
      |
  ========= '''
]
palpite = []
palavra = []
lista_carac = []

# classe
class Hangman:

    # construtor
    def __init__(self, word):
        self.word = word

    # primeira letra
    def guess(self, letter):
        self.letter = letter

    # verificar se jogo terminou
    def hangaman_over(self):
        if (board[-1]):
            return True
        else:
            return False

    # verificar se jogador venceu
    def hangman_won(self):
        if (len(palavra) == len(palpite)):
            print("Tamanho é igual")
            lista_final = list(set(palavra) - set(palpite))
            for indice, valor in enumerate(palpite):
                print("O indice é: ")
                print(indice)
                print("palpite[indice]")
                print(palpite[indice])
                print("palavra[indice]")
                palavra[indice]
                # if (palpite == palavra):
                print("tamanho da lista final")
                print(len(lista_final))
                if (len(lista_final) == 0):
                    print("entrou no true")
                    return True
                else:
                    return False
        else:
            return False

    # nao mostrar letra no board
    # def hide_word(self):

    # imprimir status do jogo
    def print_game_status(self, idx):
        self.idx = idx
        print (board[idx])


# Função para ler uma palavra de forma aleatória
def rand_word():
    with open("palavras.txt", "rt") as f:
        bank = f.readlines()
    return bank[random.randint(0, len(bank))].strip()

# Função main
def main():
    # objeto
    game = Hangman(rand_word())

    # insere a palavra sorteada na lista
    for x in game.word:
        palavra.append(x.upper())
        lista_carac.append("__|")
        palpite.append("_")

    print("palavra do jogo")
    print(palavra)

    # enquanto o jogo não encerrar, solicitar letra, ler caractere e imprimir status
    erros = 0
    acertos = 0
    game.print_game_status(0)
    print(lista_carac)
    letras_certas = []
    letras_erradas = []

    while (erros <= len(board)):
        guess_letter = input("Informe uma letra: ")
        if (guess_letter.upper() in letras_certas):
            guess_letter = input("Letra informada anteriormente. Tente outra: ")
        elif(guess_letter.upper() in letras_erradas):
            guess_letter = input("Letra informada anteriormente. Tente outra: ")

        if (guess_letter.upper() in palavra):
            acertos += 1
            indice = 0
            valor = ""
            meuIndice = []
            for indice, valor in enumerate(palavra):
                print(indice, valor)
                if (valor == guess_letter.upper()):
                    meuIndice.append(indice)
            print("meuIndice")
            print(meuIndice)
            for vlr in meuIndice:
                palpite[int(vlr)] = guess_letter.upper()
            letras_certas.append(guess_letter.upper())
            print("Letras certas: ")
            print (letras_certas)
            print("Resultado")
            print((palpite))
            print("Letras erradas: ")
            print(letras_erradas)
            if (game.hangman_won()):
                break
        else:
            erros += 1
            letras_erradas.append(guess_letter.upper())
            print("Letras certas: ")
            print (letras_certas)
            print("Letras erradas: ")
            print (letras_erradas)
        # ver status do jogo
        if (erros < len(board)):
            game.print_game_status(erros)
            print(lista_carac)

        if (erros == len(board)):
            game.hangman_won()

    # conforme status, imprime-o na tela
    if (game.hangman_won()):
        print('\nParabéns! Você venceu! Batata frita.')
    else:
        print('Melhor sorte na próxima vez')
        print('A palavra era: ' + game.word)

    print('Jogo encerrado')

# Executa a aplicação
if __name__ == "__main__":
    main()